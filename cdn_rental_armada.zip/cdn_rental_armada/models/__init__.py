# -*- coding: utf-8 -*-


from . import armada
from . import jenis_kendaraan
from . import merek
from . import kontak
from . import supir
from . import pengaturan
from . import perawatan
from . import tenaga_bantu
from . import pelanggan
from . import history
from . import varian_product
from . import account_move
from . import pemesanan

